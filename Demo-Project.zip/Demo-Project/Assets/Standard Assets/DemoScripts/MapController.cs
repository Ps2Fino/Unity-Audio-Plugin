﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

/*
 * Updates the graphics on the map in relation to the
 * objects in the game world
 * @author Daniel J. Finnegan
 * @date 27/04/2015
 */
public class MapController : MonoBehaviour {

	public GameObject player;
	public GameObject enemyPortugese;
	public GameObject enemyCat;

	private Image playerSprite;
	private float scaleFactor;

	// Use this for initialization
	void Start () {
		foreach (Image im in GetComponentsInChildren<Image>()) {
			if (im.tag.Equals("player_sprite")) {
				playerSprite = im;
			}
		}
		scaleFactor = 40f / GetComponent<RectTransform>().rect.width; // Scale factor for mapping the world to the overlay map
	}
	
	// Update is called once per frame
	void Update () {
		// Orient the player sprite
		Vector3 tempRot = playerSprite.transform.rotation.eulerAngles;
		tempRot.z = (360 - player.transform.rotation.eulerAngles.y);
		playerSprite.transform.rotation = Quaternion.Euler (tempRot);

		// Position the sprites
		foreach (Image enemySprite in GetComponentsInChildren<Image>()) {
			if (enemySprite.tag.Equals("enemy_cat_sprite")) {
				positionEnemySprite (enemyCat, enemySprite);
			}
			else if (enemySprite.tag.Equals("enemy_portugese_sprite")) {
				positionEnemySprite (enemyPortugese, enemySprite);
			}
		}
	}

	private void positionEnemySprite(GameObject enemy, Image enemySprite) {
		Vector3 playerToEnemyVector = enemy.transform.position - player.transform.position;		
		float distance = Vector3.Distance (player.transform.position, enemy.transform.position);
		Vector2 newPositionForSprite = Vector2.zero;
		newPositionForSprite.x = distance * scaleFactor * playerToEnemyVector.x;
		newPositionForSprite.y = distance * scaleFactor * playerToEnemyVector.z;
		enemySprite.rectTransform.anchoredPosition = newPositionForSprite;

		if (!GetComponent<RectTransform>().rect.Contains (enemySprite.rectTransform.anchoredPosition)) {
			enemySprite.CrossFadeAlpha (0.0f, 0.0f, true);
		} else {
			enemySprite.CrossFadeAlpha (1.0f, 0.0f, true);
		}
	}
}
